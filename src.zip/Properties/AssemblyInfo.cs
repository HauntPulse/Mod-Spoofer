﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("Mod Spoofer")]
[assembly: AssemblyDescription("Mod Spoofer by Pulse")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Pulse")]
[assembly: AssemblyProduct("Mod Spoofer by Pulse")]
[assembly: AssemblyCopyright("Copyright ©  2026")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("dc31ac22-2e11-4562-85a0-53afb9738bcc")]
[assembly: AssemblyFileVersion("1.0.0.0")]
