﻿using BepInEx;
using BepInEx.Logging;
using ExitGames.Client.Photon;
using Photon.Pun;
namespace ModSpoofer
{
    [BepInPlugin("com.ModSpoofer.by.pulse", "Mod Spoofer By Pulse", "1.0.7")]
    public class Spoof : BaseUnityPlugin
    {
        void Start ()=> ApplyCustomProperties();
        private void ApplyCustomProperties()
        {

            Hashtable props = new Hashtable
            {
                { "ObsidianMC", true },
                { "genesis", true },
                { "elux", true },
                { "VioletFreeUser", true },
                { "Hidden Menu", true },
                { "void", true },
                { "6XpyykmrCthKhFeUfkYGxv7xnXpoe2", true },
                { "cronos", true },
                { "ORBIT", true },
                { "Violet On Top", true },
                { "ElixirMenu", true },
                { "Elixir", true },
                { "VioletPaidUser", true },
                { "EmoteWheel", true },
                { "MistUser", true },
                { "Untitled", true },
                { "void_menu_open", true },
                { "dark", true },
                { "oblivionuser", true },
                { "eyerock reborn", true },
                { "asteroidlite", true },
                { "cokecosmetics", true },
                { "ØƦƁƖƬ", true },
                { "y u lookin in here weirdo", true },
                { "Atlas", true },
                { "Euphoric", true },
                { "CurrentEmote", true },
                { "Explicit", true },
                { "GFaces", true },
                { "github.com/maroon-shadow/SimpleBoards", true },
                { "github.com/ZlothY29IQ/GorillaMediaDisplay", true },
                { "GTrials", true },
                { "github.com/ZlothY29IQ/TooMuchInfo", true },
                { "github.com/ZlothY29IQ/RoomUtils-IW", true },
                { "github.com/ZlothY29IQ/MonkeClick", true },
                { "github.com/ZlothY29IQ/MonkeClick-CI", true },
                { "github.com/ZlothY29IQ/MonkeRealism", true },
                { "MediaPad", true },
                { "GorillaCinema", true },
                { "FPS-Nametags for Zlothy", true },
                { "ChainedTogetherActive", true },
                { "GPronouns", true },
                { "Fusioned", true },
                { "CSVersion", true },
                { "github.com/ZlothY29IQ/Zloth-RecRoomRig", true },
                { "ShirtProperties", true },
                { "GorillaShirts", true },
                { "GS", true },
                { "HP_Left", true },
                { "GrateVersion", true },
                { "BananaOS", true },
                { "GC", true },
                { "CarName", true },
                { "MonkePhone", true },
                { "Body Tracking", true },
                { "GorillaWatch", true },
                { "InfoWatch", true },
                { "Vivid", true },
                { "BananaPhone", true },
                { "CustomMaterial", true },
                { "cheese is gouda", true },
                { "WhoIsThatMonke", true },
                { "WhoIsThatMonke Version", true },
                { "GorillaNametags", true },
                { "DeeTags", true },
                { "Boy Do I Love Information", true },
                { "NametagsPlusPlus", true },
                { "WalkSimulator", true },
                { "Dingus", true },
                { "Graze Heath System", true },
                { "Gorilla Track Packed", true },
                { "drowsiiiGorillaInfoBoard", true },
                { "MonkeCosmetics::Material", true },
                { "github.com/arielthemonke/GorillaCraftAutoBuilder", true },
                { "usinggphys", true },
                { "Gorilla Track 2.3.0", true },
                { "GorillaTorsoEstimator", true },
                { "Body Estimation", true },
                { "tictactoe", true },
                { "ccolor", true },
                { "chainedtogether", true },
                { "goofywalkversion", true },
                { "msp", true },
                { "gorillastats", true },
                { "monkehavocversion", true },
                { "silliness", true },
                { "BoyDoILoveInformation Public", true },
                { "DTAOI", true },
                { "GorillaShop", true },
                { "DTASLOI", true },
                { "Spoofer By Pulse", "1.0.0" }
            };

            PhotonNetwork.LocalPlayer.SetCustomProperties(props, null, null);
        }
    }
}
